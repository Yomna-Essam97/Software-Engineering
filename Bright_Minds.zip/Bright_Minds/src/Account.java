
public class Account {
public	String name ;
public	int age;
public	String gender;
public String nationality;
public String email;
public  String username;
public String password;



}
